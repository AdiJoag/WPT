const express = require('express');
const users = require('url');
const app = express();
const port = 3000;

app.get('/',(req,res)=>{
    let obj = [
        FirstName = "Aditya",
        lastname = "joag"

    ]
    //console is for printing on terminal only 
    //console.log("My name is Aditya");
    
    res.send(obj);
    //res.send("My name is Aditya");
})
app.listen(port);

